# Explore Your Shoppings — deployment

## Vercel
1. Import this repository/project into Vercel.
2. Framework: Next.js.
3. Add every variable from `.env.example` in Project Settings -> Environment Variables.
4. Deploy.
5. Set APP_URL to the deployed HTTPS URL.
6. Configure Stripe webhook URL: `https://YOUR-DOMAIN/api/webhooks/stripe`.

## Docker
`docker build -t explore-your-shoppings .`
`docker run --env-file .env.local -p 3000:3000 explore-your-shoppings`

## Supabase
Create a project and run `supabase/schema.sql`. Configure Auth email settings and add the production site URL/redirects.

## Production safety
Before accepting live ad spend, add:
- verified admin role/RBAC
- encrypted OAuth token storage
- audit logs
- rate limiting
- CSRF/session protections where applicable
- campaign budget limits and approval gates
- provider-specific app review and permissions
- webhook signature verification
- monitoring and backups
