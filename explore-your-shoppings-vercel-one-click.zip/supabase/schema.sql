-- Explore Your Shoppings production database
create extension if not exists pgcrypto;

create table if not exists public.businesses (
 id uuid primary key default gen_random_uuid(),
 owner_id uuid not null references auth.users(id) on delete cascade,
 name text not null,
 email text,
 phone text,
 category text,
 created_at timestamptz not null default now()
);

create table if not exists public.campaigns (
 id uuid primary key default gen_random_uuid(),
 business_id uuid not null references public.businesses(id) on delete cascade,
 product_name text not null,
 description text not null,
 price text,
 image_url text,
 destination_url text,
 platforms text[] not null default '{}',
 status text not null default 'draft' check(status in ('draft','submitted','approved','publishing','live','completed','rejected')),
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

create table if not exists public.social_connections (
 id uuid primary key default gen_random_uuid(),
 business_id uuid not null references public.businesses(id) on delete cascade,
 provider text not null,
 provider_account_id text,
 access_token_encrypted text,
 refresh_token_encrypted text,
 expires_at timestamptz,
 created_at timestamptz not null default now(),
 unique(business_id,provider)
);

create table if not exists public.subscriptions (
 id uuid primary key default gen_random_uuid(),
 business_id uuid references public.businesses(id) on delete cascade,
 provider text not null default 'stripe',
 provider_customer_id text,
 provider_subscription_id text unique,
 plan text,
 status text,
 created_at timestamptz not null default now()
);

alter table public.businesses enable row level security;
alter table public.campaigns enable row level security;
alter table public.social_connections enable row level security;
alter table public.subscriptions enable row level security;

create policy "owners read businesses" on public.businesses for select using (owner_id=auth.uid());
create policy "owners insert businesses" on public.businesses for insert with check (owner_id=auth.uid());
create policy "owners update businesses" on public.businesses for update using (owner_id=auth.uid());

create policy "owners read campaigns" on public.campaigns for select using (
 exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=auth.uid())
);
create policy "owners create campaigns" on public.campaigns for insert with check (
 exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=auth.uid())
);
create policy "owners update campaigns" on public.campaigns for update using (
 exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=auth.uid())
);

create policy "owners read connections" on public.social_connections for select using (
 exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=auth.uid())
);
create policy "owners read subscriptions" on public.subscriptions for select using (
 exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=auth.uid())
);
