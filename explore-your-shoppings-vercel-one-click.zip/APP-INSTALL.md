# Easy app access

Explore Your Shoppings is now a Progressive Web App (PWA).

## Android / Chrome
1. Deploy the project to HTTPS (Vercel is recommended).
2. Open the website in Chrome.
3. Tap the browser menu (⋮).
4. Tap **Install app** or **Add to Home screen**.
5. The Explore Your Shoppings icon will appear like a normal app.

## iPhone / iPad
Open the site in Safari -> Share -> **Add to Home Screen**.

## Important
The PWA requires HTTPS in production. The app package does not contain your private API credentials; add those as server-side environment variables in your hosting provider.
