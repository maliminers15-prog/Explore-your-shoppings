# API setup
Meta: create an approved Meta developer/business app, enable Marketing API, obtain the required permissions and advertiser authorization, then set META_* variables.
TikTok: create a TikTok developer app, add required products/scopes, configure the OAuth redirect URI, and pass review as required. Set TIKTOK_* variables.
Google Ads: create Google Cloud/Ads credentials and obtain a developer token and OAuth refresh token. Set GOOGLE_ADS_* variables.
Never expose secrets as NEXT_PUBLIC_* values. Production needs secure DB, encrypted token storage, authentication, audit logs and rate limiting.
