'use client'
import {useState} from 'react'
import {createClient} from '../../lib/supabase/client'
export default function Auth(){
 const [mode,setMode]=useState('login'),[email,setEmail]=useState(''),[password,setPassword]=useState(''),[msg,setMsg]=useState('')
 async function submit(e){e.preventDefault();const s=createClient();const r=mode==='login'?await s.auth.signInWithPassword({email,password}):await s.auth.signUp({email,password});setMsg(r.error?r.error.message:mode==='login'?'Signed in. Open dashboard.':'Account created. Check your email if confirmation is enabled.')}
 return <main className="form"><h1>🛍️ Explore Your Shoppings</h1><h2>{mode==='login'?'Business Login':'Create Business Account'}</h2><form onSubmit={submit}><div className="field"><label>Email</label><input type="email" value={email} onChange={e=>setEmail(e.target.value)} required/></div><div className="field"><label>Password</label><input type="password" value={password} onChange={e=>setPassword(e.target.value)} minLength="8" required/></div><button className="btn">{mode==='login'?'Sign in':'Create account'}</button></form><p>{msg}</p><button className="btn secondary" onClick={()=>setMode(mode==='login'?'signup':'login')}>{mode==='login'?'Create an account':'Back to login'}</button></main>
}
