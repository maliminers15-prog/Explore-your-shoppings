import {createClient} from '../../../lib/supabase/server'
export async function POST(req){
 const supabase=await createClient()
 const {data:{user}}=await supabase.auth.getUser()
 if(!user)return Response.json({error:'Unauthorized'},{status:401})
 const b=await req.json()
 if(!b.business_id||!b.product_name||!b.description)return Response.json({error:'business_id, product_name and description are required'},{status:400})
 const {data:business}=await supabase.from('businesses').select('id').eq('id',b.business_id).eq('owner_id',user.id).single()
 if(!business)return Response.json({error:'Business not found'},{status:404})
 const {data,error}=await supabase.from('campaigns').insert({...b,status:'submitted'}).select().single()
 if(error)return Response.json({error:error.message},{status:400})
 return Response.json({ok:true,campaign:data})
}
