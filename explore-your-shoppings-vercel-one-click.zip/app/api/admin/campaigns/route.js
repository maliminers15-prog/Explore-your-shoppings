import {createClient} from '../../../lib/supabase/server'
export async function GET(){
 const s=await createClient(); const {data:{user}}=await s.auth.getUser()
 if(!user)return Response.json({error:'Unauthorized'},{status:401})
 // Replace with a server-side admin-role check before production use.
 const {data,error}=await s.from('campaigns').select('*,businesses(name,email)').order('created_at',{ascending:false})
 if(error)return Response.json({error:error.message},{status:400})
 return Response.json({campaigns:data})
}
