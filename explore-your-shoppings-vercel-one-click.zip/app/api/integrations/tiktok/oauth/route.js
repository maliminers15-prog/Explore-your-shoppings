export async function GET(){
 const key=process.env.TIKTOK_CLIENT_KEY, redirect=process.env.TIKTOK_REDIRECT_URI
 if(!key||!redirect)return Response.json({configured:false})
 return Response.json({configured:true,authorizationUrl:'https://www.tiktok.com/v2/auth/authorize/?client_key='+encodeURIComponent(key)+'&response_type=code&scope=user.info.basic&redirect_uri='+encodeURIComponent(redirect)})
}
