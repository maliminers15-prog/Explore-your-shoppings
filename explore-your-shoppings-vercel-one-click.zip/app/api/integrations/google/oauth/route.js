export async function GET(){
 const id=process.env.GOOGLE_ADS_CLIENT_ID, redirect=process.env.APP_URL+'/api/integrations/google/oauth/callback'
 if(!id)return Response.json({configured:false})
 const url='https://accounts.google.com/o/oauth2/v2/auth?client_id='+encodeURIComponent(id)+'&redirect_uri='+encodeURIComponent(redirect)+'&response_type=code&access_type=offline&prompt=consent&scope='+encodeURIComponent('https://www.googleapis.com/auth/adwords')
 return Response.json({configured:true,authorizationUrl:url})
}
