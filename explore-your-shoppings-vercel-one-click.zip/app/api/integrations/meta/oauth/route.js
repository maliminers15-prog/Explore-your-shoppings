export async function GET(){
 const app=process.env.META_APP_ID, redirect=process.env.APP_URL+'/api/integrations/meta/oauth/callback'
 if(!app)return Response.json({configured:false})
 const url='https://www.facebook.com/v23.0/dialog/oauth?client_id='+encodeURIComponent(app)+'&redirect_uri='+encodeURIComponent(redirect)+'&response_type=code&scope=ads_management,ads_read,business_management'
 return Response.json({configured:true,authorizationUrl:url})
}
