import Stripe from 'stripe'
export async function POST(req){
 if(!process.env.STRIPE_SECRET_KEY)return Response.json({error:'Stripe is not configured'},{status:503})
 try{
  const {email,priceId}=await req.json()
  if(!email||!priceId)return Response.json({error:'email and priceId are required'},{status:400})
  const stripe=new Stripe(process.env.STRIPE_SECRET_KEY)
  const session=await stripe.checkout.sessions.create({
   mode:'subscription',customer_email:email,
   line_items:[{price:priceId,quantity:1}],
   success_url:`${process.env.APP_URL}/dashboard?payment=success`,
   cancel_url:`${process.env.APP_URL}/advertise?payment=cancelled`,
   metadata:{product:'Explore Your Shoppings'}
  })
  return Response.json({url:session.url})
 }catch(e){return Response.json({error:e.message},{status:500})}
}
