import Stripe from 'stripe'
export async function POST(req){
 const sig=req.headers.get('stripe-signature')
 const secret=process.env.STRIPE_WEBHOOK_SECRET
 if(!secret||!process.env.STRIPE_SECRET_KEY)return new Response('Stripe webhook not configured',{status:503})
 const body=await req.text()
 try{
  const event=new Stripe(process.env.STRIPE_SECRET_KEY).webhooks.constructEvent(body,sig,secret)
  // Production: persist subscription/customer state in Supabase here.
  if(['checkout.session.completed','customer.subscription.updated','customer.subscription.deleted'].includes(event.type)){
    console.log('Stripe event:',event.type)
  }
  return Response.json({received:true})
 }catch(e){return new Response(`Webhook Error: ${e.message}`,{status:400})}
}
