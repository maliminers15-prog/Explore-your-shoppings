'use client';
import {useState} from 'react';
export default function Advertise(){
const [sent,setSent]=useState(false);
function submit(e){e.preventDefault();const f=new FormData(e.currentTarget);localStorage.setItem('advertiser',JSON.stringify(Object.fromEntries(f)));setSent(true)}
return <><nav className="nav"><a className="logo" href="/">🛍️ Explore Your Shoppings</a><a href="/">Home</a></nav><main className="form"><h1>Advertise your business</h1><p className="muted">Create your advertiser account and campaign request.</p>{sent?<><h2>Application saved ✅</h2><p>Your demo advertiser profile is ready. Continue to the dashboard.</p><a className="btn" href="/dashboard">Open Dashboard</a></>:<form onSubmit={submit}>
<div className="field"><label>Business name</label><input name="business" required/></div>
<div className="field"><label>Owner / contact name</label><input name="contact" required/></div>
<div className="field"><label>Email</label><input type="email" name="email" required/></div>
<div className="field"><label>Phone / WhatsApp</label><input name="phone" required/></div>
<div className="field"><label>Business category</label><select name="category"><option>Fashion</option><option>Baby & Kids</option><option>Electronics</option><option>Food</option><option>Beauty</option><option>Home</option><option>Other</option></select></div>
<div className="field"><label>Advertising plan</label><select name="plan"><option>Starter</option><option>Business</option><option>Premium</option></select></div>
<button className="btn">Create advertiser account</button></form>}</main></>}
