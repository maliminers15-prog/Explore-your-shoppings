import './globals.css';
export const metadata = {
  manifest: '/manifest.webmanifest',
  title: 'Explore Your Shoppings 🛍️',
  description: 'Discover products. Promote businesses. Grow sales.'
};
export default function RootLayout({children}) {
  return <html lang="en"><body>{children}<script dangerouslySetInnerHTML={{__html:`if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js'))}`}} /></body></html>;
}