import {createServerClient} from '@supabase/ssr'
import {NextResponse} from 'next/server'
export async function middleware(request){
 let response=NextResponse.next({request})
 const supabase=createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL,process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY,{cookies:{getAll(){return request.cookies.getAll()},setAll(cs){cs.forEach(({name,value,options})=>{request.cookies.set(name,value);response.cookies.set(name,value,options)})}}})
 await supabase.auth.getUser()
 return response
}
export const config={matcher:['/dashboard/:path*','/admin/:path*']}
