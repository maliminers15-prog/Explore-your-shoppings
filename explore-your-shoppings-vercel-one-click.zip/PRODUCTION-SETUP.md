# Production launch

## Database + login
Create a Supabase project and run `supabase/schema.sql` in its SQL Editor. Add the Supabase URL and publishable key to deployment environment variables. Supabase Auth supports email/password and other auth methods; RLS policies in the schema isolate business data.

## Subscriptions
Create recurring Stripe Prices for Starter, Business and Premium. Put their Price IDs in the environment. The `/api/checkout` endpoint creates hosted Stripe Checkout subscription sessions. Configure Stripe's webhook endpoint at `/api/webhooks/stripe` and set `STRIPE_WEBHOOK_SECRET`.

## Social accounts
Use OAuth for each advertiser's own account. Never ask businesses for social-media passwords. Store tokens server-side and encrypted. Provider permissions and app review are required before production publishing.

## Deployment
Deploy the Next.js app to a Node-compatible host. Add all environment variables in the host's secret/environment-variable settings, then build with `npm run build`.

## Campaign flow
draft -> submitted -> admin review -> approved -> publishing -> live -> completed

The current provider adapters deliberately stop at a "ready" state until each provider account has completed OAuth and the provider has approved the requested capabilities.
