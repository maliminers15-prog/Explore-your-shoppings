# Explore Your Shoppings 🛍️

Multi-business advertising platform starter.

## Included
- Public landing page
- Business advertiser signup
- Advertiser dashboard
- Subscription-plan selection
- Campaign creation
- Social platform selection
- Admin dashboard
- API-ready project structure

## Run
1. Install Node.js 18+.
2. `npm install`
3. `npm run dev`
4. Open http://localhost:3000

This starter uses local browser storage for demo data. For production, connect a secure database, authentication provider, payment gateway, and official social-media APIs.

## API integrations
This version includes server-side integration endpoints for Meta, TikTok OAuth configuration, and Google Ads configuration, plus a campaign publish orchestration endpoint. Add credentials from `.env.example` to `.env.local` and deploy with those values stored as server-side environment secrets.
