# Explore Your Shoppings 🛍️ — Vercel Deployment

This project is prepared for deployment on Vercel.

## Fastest deployment

1. Upload this project to a GitHub repository.
2. In Vercel, choose **Add New → Project**.
3. Import the GitHub repository.
4. Vercel should detect **Next.js** automatically.
5. Add the environment variables from `.env.example`.
6. Click **Deploy**.

## Important

The app can deploy without every optional advertising integration configured. Add the relevant production credentials before enabling those integrations.

Required for the core authenticated production setup:
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`

For payments:
- `STRIPE_SECRET_KEY`
- `STRIPE_WEBHOOK_SECRET`
- `STRIPE_STARTER_PRICE_ID`
- `STRIPE_BUSINESS_PRICE_ID`
- `STRIPE_PREMIUM_PRICE_ID`

For Meta/TikTok/Google advertising, configure the corresponding variables in `.env.example`.

## After deployment

Set:
- `APP_URL` = your Vercel production URL

Then configure the same production URL and callback paths in your Supabase, Stripe, Meta, TikTok, and Google developer dashboards where applicable.

## Install as an app

Open the deployed HTTPS site on Android Chrome and select:
**⋮ → Install app** (or **Add to Home screen**).

The project includes a web app manifest and service worker.
